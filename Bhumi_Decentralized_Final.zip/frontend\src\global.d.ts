declare namespace JSX {
  interface IntrinsicElements {
    'w3m-button': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & { balance?: 'show' | 'hide'; size?: 'sm' | 'md' | 'lg' };
  }
}
